import { View, Text } from "react-native";

function BookmarksScreen() {
  return (
    <View>
      <Text>Bookmarked News Screen</Text>
    </View>
  );
}

export default BookmarksScreen;
