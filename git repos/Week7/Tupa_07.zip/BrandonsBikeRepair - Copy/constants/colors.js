const Colors = {
  accent500: "#31303a",
  primary500: "#b74532",
};

export default Colors;
