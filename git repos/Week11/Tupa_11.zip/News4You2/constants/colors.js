const Colors = {
  accent200: "#F39c12",
  accent500: "#E74c3c",
  accent800: "#ECF0F1",
  primary300o5: "rgba(255, 255, 255, 0.5)",
  primary300: "#FFFFFF",
  primary500o8: "rgba(52, 73, 94, 0.8)",
  primary500: "#34495E",
  primary800: "#2C3E50",
};

export default Colors;
