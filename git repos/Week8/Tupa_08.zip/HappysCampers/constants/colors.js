const Colors = {
  accent300: "rgb(223, 132, 13)",
  accent500: "#551a8b",
  primary300o5: "rgba(223, 132, 13, 0.5)",
  primary300: "#4e4e4e",
  primary500: "rgb(186, 218, 85)",
  primary800: "rgb(223, 13, 13)",
};

export default Colors;
